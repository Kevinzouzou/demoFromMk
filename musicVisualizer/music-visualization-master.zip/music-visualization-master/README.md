# music-visualization
HTML5音乐可视化

预览
![image](https://github.com/ahiba/music-visualization/raw/master/Music-Misualization柱状图.png)

![image](https://github.com/ahiba/music-visualization/raw/master/Music-Misualization球状图.png)